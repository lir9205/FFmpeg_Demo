//
//  ViewController.m
//  LR_FFmpeg_Audio_Decode
//
//  Created by admin on 2017/12/29.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import "ViewController.h"
#import "FFmpegTest.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //音频解码
    [self audioDecode];
}


//音频解码
- (void)audioDecode {
    
    NSString *inStr = [NSString stringWithFormat:@"Video.bundle/%@", @"Test.mov"];
    NSString *inPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:inStr];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentationDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    NSString *tmpPath = [path stringByAppendingPathComponent:@"temp"];
    [[NSFileManager defaultManager] createDirectoryAtPath:tmpPath withIntermediateDirectories:YES attributes:nil error:NULL];
    NSString *outFilePath = [tmpPath stringByAppendingPathComponent:[NSString stringWithFormat:@"Test.pcm"]];
    
    [FFmpegTest ffmpegDecodeAudioWithSourceFilePath:inPath targetFilePath:outFilePath];
    
    NSLog(@"sourcePath: %@,targetPath: %@", inPath, outFilePath);
}


@end
