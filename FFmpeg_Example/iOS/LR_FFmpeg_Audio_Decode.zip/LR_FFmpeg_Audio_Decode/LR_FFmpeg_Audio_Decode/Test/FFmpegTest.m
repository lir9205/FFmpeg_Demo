//
//  FFmpegTest.m
//  LR_20171223_FFmpeg_Demo_iOS
//
//  Created by admin on 2017/12/23.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import "FFmpegTest.h"

@implementation FFmpegTest

//音频解码
+ (void)ffmpegDecodeAudioWithSourceFilePath:(NSString *)sourceFilePath targetFilePath:(NSString *)targetFilePath {

    // 第一步：注册组件
    av_register_all();
    // 第二步：打开封装格式 -> 打开文件
    // 参数一 AVFormatContext **ps 封装格式上下文
    // 作用：保存整个视频信息（解码器，编码器等等...）
    // 信息：码率，帧率等...
    AVFormatContext *avformat_context = avformat_alloc_context();
    // 参数二 const char *url 打开视频路径
    // 将 Java 的字符串转成 C语言的字符串
    const char *cfilePath = [sourceFilePath UTF8String];
    // 参数三 AVInputFormat *fmt 指定输入封装格式 -> 默认格式
    // 参数四 AVDictionary **options 指定默认配置信息 -> 默认配置
    int avformat_open_input_result =  avformat_open_input(&avformat_context, cfilePath, NULL, NULL);
    
    if (avformat_open_input_result != 0) {
        NSLog(@"打开文件失败");
        return;
    }
    NSLog(@"打开文件成功");
    
    
    // 第三步： 查找视频基本信息
    // 参数一 AVFormatContext *ps 封装格式上下文
    // 参数二 AVDictionary **options 指定默认配置信息 -> 默认配置
    int avformat_find_stream_info_result = avformat_find_stream_info(avformat_context, NULL);
    if (avformat_find_stream_info_result < 0) {
        NSLog(@"查找音频流失败");
        return;
    }
    
    // 第四步：查找音频解码器
    // 1. 查找音频流索引位置
    int av_stream_index = -1;
    for (int i = 0; i < avformat_context -> nb_streams; ++i) {
        // 判断流类型：视频流、音频流(AVMEDIA_TYPE_AUDIO)、字母流。。。
        // codec 视频流的解码器；codec_type：解码器类型
        if (avformat_context->streams[i]->codec->codec_type == AVMEDIA_TYPE_AUDIO) {
            av_stream_index = i;
            break;
        }
        
        //        if (avformat_context->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_AUDIO) {
        //            av_stream_index = i;
        //            break;
        //        }
    }
    
    //2. 根据音频流索引，获取音频解码器上下文
    AVCodecContext *avcodec_context = avformat_context->streams[av_stream_index]->codec;
    //    AVCodecParameters *avCodecParameters = avformat_context->streams[av_stream_index]->codecpar;
    
    //3. 根据解码器上下文，获得解码器ID，然后查找解码器
//    AVCodec *avcodec = avcodec_find_decoder(avcodec_context->codec_id);
    AVCodec *avcodec = avcodec_find_decoder_by_name("libfdk_aac");
    if (avcodec == NULL) {
        NSLog(@"查找音频解码器失败");
        return;
    }
    
    
    //第五步：打开音频解码器
    int avcodec_open2_result = avcodec_open2(avcodec_context, avcodec, NULL);
    if (avcodec_open2_result != 0) {
        NSLog(@"打开音频解码器失败");
        return;
    }
    
    // 测试一下
    // 打印信息
    NSLog(@"解码器名称：%s", avcodec->name);
    
    
    //第六步：循环读取音频压缩数据
    //每读取一帧数据，立马解码一帧数据
    
    // 6.1 创建音频压缩数据帧
    // 音频压缩数据：AAC 格式，MP3格式
    AVPacket *avPacket = (AVPacket *)av_malloc(sizeof(AVPacket));//动态分配内存
    
    // 7.2 创建音频采样数据帧
    AVFrame *avFrame = av_frame_alloc();
    
    //7.3 类型转换
    //音频采样上下文->开辟了一块内存空间->pcm 格式
    //设置参数：要保证视频能够正常播放，必须满足采样率44100HZ, 声道为双声道，编码为16位 PCM
    //参数一：s -> 音频采样数据上下文
    //上下文：保存音频信息
    SwrContext *swr_context = swr_alloc();
    //参数二：out_ch_layout -> 输出声道布局类型（立体声，环绕声、机器人等等。。。）
    int out_ch_layout = AV_CH_LAYOUT_STEREO;
    //int out_ch_layout = av_get_default_channel_layout(avcodec_context->channels);
    //参数三：out_sample_fmt -> 输出采样精度(编码)，例如：采样精度8位=每个像素点1字节，采样精度16位=2字节
    // 错误的写法
    //AVSampleFormat out_sample_fmt = avcodec_context->sample_fmt;
    // 正确写法：保证输出的编码是16位
    enum AVSampleFormat out_sample_fmt = AV_SAMPLE_FMT_S16;
    
    //参数四：out_sample_rate -> 输出采样率（一般是44100HZ）
    int out_sample_rate = avcodec_context->sample_rate;
    //参数五： in_ch_layout -> 输入声道布局类型
    int64_t in_ch_layout = av_get_default_channel_layout(avcodec_context->channels);
    //参数六： in_sample_fmt -> 输入采样精度
    enum AVSampleFormat in_sample_fmt = avcodec_context->sample_fmt;
    //参数七： in_sample_rate -> 输入采样率
    int in_sample_rate = avcodec_context->sample_rate;
    //参数八： log_offset ->  Log 日志
    int log_offset = 0;
    //参数九： log_ctx ->  Log 上下文
    
    swr_alloc_set_opts(swr_context,
                       out_ch_layout,
                       out_sample_fmt,
                       out_sample_rate,
                       in_ch_layout,
                       in_sample_fmt,
                       in_sample_rate,
                       log_offset,
                       NULL);
    // 初始化音频采样数据上下文
    swr_init(swr_context);
    
    //输出音频采样数据
    //缓冲区的大小 = 采样率(44100HZ) * 采样精度（16位 = 2字节）
    int MAX_AUDIO_SIZE = 44100 * 2;
    uint8_t *out_buffer = (uint8_t *)av_malloc(MAX_AUDIO_SIZE);
    
    //输出的声道数量
    int out_nb_channels = av_get_channel_layout_nb_channels(out_ch_layout);
    
    
    int audio_decode_result = 0;
    
    //7.5 打开文件
    const  char *coutfilePath = [targetFilePath UTF8String];
    FILE *out_file_pcm = fopen(coutfilePath, "wb");
    if (out_file_pcm == NULL) {
        NSLog(@"打开音频输出文件失败");
        return;
    }
    
    
    // 统计帧数
    int current_index = 0;
    
    while (av_read_frame(avformat_context, avPacket) >= 0) {
        //>=: 读取到了
        // <0:读取错误或者读取完毕
        // 6.2 判定是否是我们的音频流
        if (avPacket -> stream_index == av_stream_index) {
            //第七步：音频解码
            //7.1  发送一帧音频压缩数据包 得到 音频压缩数据帧
            avcodec_send_packet(avcodec_context, avPacket);
            //7.2  解码一帧音频压缩数据包，得到一帧音频采样数据帧
            audio_decode_result = avcodec_receive_frame(avcodec_context, avFrame);
            if (audio_decode_result == 0) {
                //解码成功
                NSLog(@"音频解码成功");
                
                //7.3 类型转换(音频采样数据格式有很多种)
                //将解码出来的的音频采样数据格式统一转为 pcm 格式
                //参数一：音频采样数据上下文
                //参数二：输出音频采样数据
                //参数三：输出音频采样数据的大小
                //参数四：输入音频采样数据
                //参数五：输入音频采样数据的大小
                swr_convert(swr_context,
                            &out_buffer,
                            MAX_AUDIO_SIZE,
                            (const uint8_t **)avFrame->data,
                            avFrame->nb_samples);
                
                //7.4 获取缓冲区实际存储大小
                //参数一：行大小，可以为 NULL
                //参数二：输出声道的数量
                //参数三：输入的大小
                int nb_samples = avFrame->nb_samples;
                //参数四：输出音频采样数据格式
                //参数五：字节对齐方式
                int out_buffer_size = av_samples_get_buffer_size(NULL,
                                                                 out_nb_channels,
                                                                 nb_samples,
                                                                 out_sample_fmt,
                                                                 1);
                
                
                
                
                //7.5 写入文件
                fwrite(out_buffer, 1, out_buffer_size, out_file_pcm);
                
                // 统计帧数
                current_index++;
                NSLog(@"当前解码第%d帧",current_index);//598帧
            }
        }
        
        
    }
    
    
    //第八步：释放内存资源，关闭音频
    fclose(out_file_pcm);
    av_packet_free(&avPacket);
    swr_free(&swr_context);
    av_free(out_buffer);
    av_frame_free(&avFrame);
    avcodec_close(avcodec_context);
    avformat_close_input(&avformat_context);
}

@end
