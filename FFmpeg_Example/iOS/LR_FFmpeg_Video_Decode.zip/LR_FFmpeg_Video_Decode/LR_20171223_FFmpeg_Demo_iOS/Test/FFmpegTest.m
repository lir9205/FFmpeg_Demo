//
//  FFmpegTest.m
//  LR_20171223_FFmpeg_Demo_iOS
//
//  Created by admin on 2017/12/23.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import "FFmpegTest.h"

@implementation FFmpegTest

//视频解码
+ (void)ffmpegDecodeVideoWithSourceFilePath:(NSString *)sourceFilePath targetFilePath:(NSString *)targetFilePath {
    // 第一步：注册组件
    av_register_all();
    //    第二步：打开封装格式 -> 打开文件
    // 参数一 封装格式上下文
    // 作用：保存整个视频信息（解码器，编码器等等...）
    // 信息：码率，帧率等...
    AVFormatContext *avformat_context = avformat_alloc_context();
    // 参数二 视频路径
    // 将 Java 的字符串转成 C语言的字符串
    const char *cfilePath = [sourceFilePath UTF8String];
    
    
    // 参数三 指定输入封装格式 -> 默认格式
    // 参数四 指定默认配置信息 -> 默认配置
    int avformat_open_input_result =  avformat_open_input(&avformat_context, cfilePath, NULL, NULL);
    
    if (avformat_open_input_result != 0) {
        NSLog(@"输入文件打开失败");
        return;
    }
    
    // 第三步： 查找视频流 -> 拿到视频信息
    // 参数一 AVFormatContext *ps 封装格式上下文
    // 参数二 AVDictionary **options 指定默认配置信息 -> 默认配置
    int avformat_find_stream_info_result = avformat_find_stream_info(avformat_context, NULL);
    if (avformat_find_stream_info_result < 0) {
        NSLog(@"查找视频流失败");
        return;
    }
    
    // 第四步：查找视频解码器
    // 1. 查找视频流索引位置
    int av_stream_index = -1;
    for (int i = 0; i < avformat_context -> nb_streams; ++i) {
        // 判断流类型：视频流、音频流、字母流。。。
        // codec 视频流的解码器；codec_type：解码器类型
        if (avformat_context->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
            av_stream_index = i;
            break;
        }
        
        //        if (avformat_context->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
        //            av_stream_index = i;
        //            break;
        //        }
    }
    
    //2. 根据视频流索引，获取解码器上下文
    AVCodecContext *avcodec_context = avformat_context->streams[av_stream_index]->codec;
    //    AVCodecParameters *avCodecParameters = avformat_context->streams[av_stream_index]->codecpar;
    
    //3. 根据解码器上下文，获得解码器ID，然后查找解码器
    AVCodec *avcodec = avcodec_find_decoder(avcodec_context->codec_id);
    
    //第五步：打开解码器
    int avcodec_open2_result = avcodec_open2(avcodec_context, avcodec, NULL);
    if (avcodec_open2_result != 0) {
        NSLog(@"打开解码器失败");
        return;
    }
    
    // 测试一下
    // 打印信息
    NSLog(@"解码器名称：%s", avcodec->name);  //解码器名称：h264
    
    
    
    
    //第七步 视频解码->播放视频->得到视频像素数据
    //1.2 解码一帧视频压缩数据->进行解码（作用：用于解码操作）
    // 开辟一块内存空间
    AVFrame *avframe_in = av_frame_alloc();
    int decode_result = 0;
    
    //2、注意：这里不能够保证解码出来的一帧视频像素格式是 yuv 格式
    //参数一：源文件 -> 原始视频像素数据格式宽
    //参数二：源文件 -> 原始视频像素数据格式高
    //参数三：源文件 -> 原始视频像素数据格式类型
    //参数四：目标文件 -> 目标视频像素数据格式宽
    //参数五：目标文件 -> 目标视频像素数据格式高
    //参数六：目标文件 -> 目标视频像素数据格式类型
    struct SwsContext *swsContext = sws_getContext(avcodec_context->width,
                                            avcodec_context->height,
                                            avcodec_context->pix_fmt,
                                            avcodec_context->width,
                                            avcodec_context->height,
                                            AV_PIX_FMT_YUV420P,
                                            SWS_BICUBIC, NULL, NULL, NULL);
    
    
    //创建一个 yuv420p 视频像素数据格式缓冲区（一帧数据）
    AVFrame *avframe_yuv420p = av_frame_alloc();
    //给缓冲区设置类型->yuv420p 类型
    //得到 yuv420p缓冲区大小
    //参数一：视频像素数据格式类型 -> yuv420p格式
    //参数二：一帧视频像素数据宽 = 视频宽
    //参数三：一帧视频像素数据高 = 视频高
    //参数四：字节对齐方式->默认是1
    int buffer_size = av_image_get_buffer_size(AV_PIX_FMT_YUV420P,
                                               avcodec_context->width,
                                               avcodec_context->height,
                                               1);
    //开辟一块内存空间
    uint8_t *out_buffer = (uint8_t *)av_malloc(buffer_size);
    
    //向 avframe_yuv420p 填充数据
    //参数一：目标->填充数据（avframe_yuv420p）
    //参数二：目标->每一行大小
    //参数三：原始数据
    //参数四：目标->格式类型
    //参数五：宽
    //参数六：高
    //参数七：字节对齐方式->默认是1
    av_image_fill_arrays(avframe_yuv420p->data,
                         avframe_yuv420p->linesize,
                         out_buffer,
                         AV_PIX_FMT_YUV420P,
                         avcodec_context->width,
                         avcodec_context->height,
                         1);
    
    int y_size, u_size, v_size;
    
    //3.2 将 yuv420p 数据写入.yuv 文件
    //打开写入文件
    const char *outfile = [targetFilePath UTF8String];
    FILE *file_yuv420p = fopen(outfile, "wb+");
    if (file_yuv420p == NULL) {
        NSLog(@"输出文件打开失败");
        return;
    }
    
    // 统计帧数
    int current_index = 0;
    
    //第六步：读取视频压缩数据->循环读取
    //每读取一帧数据，立马解码一帧数据
    // 1、分析av_read_frame()参数
    // 参数一：封装格式上下文
    // 参数二：一帧压缩数据 = 一帧图片
    
    AVPacket *packet = (AVPacket *)av_malloc(sizeof(AVPacket));//动态分配内存
    
    while (av_read_frame(avformat_context, packet) >= 0) {
        //>=: 读取到了
        //<0:读取错误或者读取完毕
        // 2、判定是否是我们的视频流
        if (packet -> stream_index == av_stream_index) {
            //第七步：视频解码->播放视频->得到视频像素数据
            //1、解码一帧压缩数据->得到视频像素数据->yuv格式
            //采用新的 API
            //1.1 发送一帧视频压缩数据
            avcodec_send_packet(avcodec_context, packet);
            //1.2 解码一帧视频压缩数据->进行解码（作用：用于解码操作）
            decode_result = avcodec_receive_frame(avcodec_context, avframe_in);
            if (decode_result == 0) {
                //解码成功
                NSLog(@"视频解码成功");
                
                //2、注意：这里不能够保证解码出来的一帧视频像素格式是 yuv 格式
                //视频像素数据格式有很多类型：yuv420p、yuv422p、yuv444p 等等...  yuv指的是色度空间，420指的是色度抽样
                //保证我的解码后的视频像素数据格式统一为 yuv420p -> 通用的格式
                //进行类型转换：将解码出来的视频像素点数据格式->统一转类型为yuv420p
                //sws_scale作用：进行类型转换的
                //参数一：视频像素数据格式上下文
                //参数二：原来的视频像素格式 -> 输入数据
                //参数三：原来的视频像素格式 -> 输入画面每一行大小
                //参数四：原来的视频像素格式 -> 输入画面每一行开始位置（填写：0 -> 表示从原点开始读取）
                //参数五：原来的视频像素格式 -> 输入数据行数
                //参数六：转换类型后视频像素数据格式->输出数据
                //参数七：转换类型后视频像素数据格式->输出画面每一行大小
                sws_scale(swsContext,
                          (const uint8_t *const *)avframe_in->data,
                          avframe_in->linesize,
                          0,
                          avcodec_context->height,
                          avframe_yuv420p->data,
                          avframe_yuv420p->linesize);
                //方式一：直接显示在屏幕上面去
                //方式二：写入 yuv 文件格式
                //3、将 yuv420p数据写入.yuv 文件中
                //3.1 计算 YUV 大小
                //分析一下原理？
                //Y: 亮度，UV: 色度
                //有规律
                //YUV420P 格式规范一：Y结构表示一个像素（一个像素对应一个 Y）
                //YUV420P 格式规范二：四个像素点对应一个（ U 和 V：4Y = U = V）
                y_size = avcodec_context->width * avcodec_context->height;
                u_size = y_size / 4;
                v_size = y_size / 4;
                
                //3.2 写入.yuv 文件
                //  yuv格式从左到右，自上而下的顺序排版
                //首先 y 数据
                fwrite(avframe_yuv420p->data[0], 1, y_size, file_yuv420p);
                //其次 u 数据
                fwrite(avframe_yuv420p->data[1], 1, u_size, file_yuv420p);
                //再其次 v 数据
                fwrite(avframe_yuv420p->data[2], 1, v_size, file_yuv420p);
                
                current_index++;
                NSLog(@"当前解码第%d帧", current_index);
            }
        }
        
        
    }
    
    
    //第八步：释放内存资源，关闭解码器->解码完成
    // 注意释放顺序，不要搞反了
    av_packet_free(&packet);
    fclose(file_yuv420p);
    av_frame_free(&avframe_in);
    av_frame_free(&avframe_yuv420p);
    free(out_buffer);
    avcodec_close(avcodec_context);
    avformat_free_context(avformat_context);
    
}

//音频解码
+ (void)ffmpegDecodeAudioWithSourceFilePath:(NSString *)sourceFilePath targetFilePath:(NSString *)targetFilePath {

    // 第一步：注册组件
    av_register_all();
    // 第二步：打开封装格式 -> 打开文件
    // 参数一 AVFormatContext **ps 封装格式上下文
    // 作用：保存整个视频信息（解码器，编码器等等...）
    // 信息：码率，帧率等...
    AVFormatContext *avformat_context = avformat_alloc_context();
    // 参数二 const char *url 打开视频路径
    // 将 Java 的字符串转成 C语言的字符串
    const char *cfilePath = [sourceFilePath UTF8String];
    // 参数三 AVInputFormat *fmt 指定输入封装格式 -> 默认格式
    // 参数四 AVDictionary **options 指定默认配置信息 -> 默认配置
    int avformat_open_input_result =  avformat_open_input(&avformat_context, cfilePath, NULL, NULL);
    
    if (avformat_open_input_result != 0) {
        NSLog(@"打开文件失败");
        return;
    }
    NSLog(@"打开文件成功");
    
    
    // 第三步： 查找视频基本信息
    // 参数一 AVFormatContext *ps 封装格式上下文
    // 参数二 AVDictionary **options 指定默认配置信息 -> 默认配置
    int avformat_find_stream_info_result = avformat_find_stream_info(avformat_context, NULL);
    if (avformat_find_stream_info_result < 0) {
        NSLog(@"查找音频流失败");
        return;
    }
    
    // 第四步：查找音频解码器
    // 1. 查找音频流索引位置
    int av_stream_index = -1;
    for (int i = 0; i < avformat_context -> nb_streams; ++i) {
        // 判断流类型：视频流、音频流(AVMEDIA_TYPE_AUDIO)、字母流。。。
        // codec 视频流的解码器；codec_type：解码器类型
        if (avformat_context->streams[i]->codec->codec_type == AVMEDIA_TYPE_AUDIO) {
            av_stream_index = i;
            break;
        }
        
        //        if (avformat_context->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_AUDIO) {
        //            av_stream_index = i;
        //            break;
        //        }
    }
    
    //2. 根据音频流索引，获取音频解码器上下文
    AVCodecContext *avcodec_context = avformat_context->streams[av_stream_index]->codec;
    //    AVCodecParameters *avCodecParameters = avformat_context->streams[av_stream_index]->codecpar;
    
    //3. 根据解码器上下文，获得解码器ID，然后查找解码器
    AVCodec *avcodec = avcodec_find_decoder(avcodec_context->codec_id);
    if (avcodec == NULL) {
        NSLog(@"查找音频解码器失败");
        return;
    }
    
    
    //第五步：打开音频解码器
    int avcodec_open2_result = avcodec_open2(avcodec_context, avcodec, NULL);
    if (avcodec_open2_result != 0) {
        NSLog(@"打开音频解码器失败");
        return;
    }
    
    // 测试一下
    // 打印信息
    NSLog(@"解码器名称：%s", avcodec->name); // 解码器名称：aac
    
    
    //第六步：循环读取音频压缩数据
    //每读取一帧数据，立马解码一帧数据
    
    // 6.1 创建音频压缩数据帧
    // 音频压缩数据：AAC 格式，MP3格式
    AVPacket *avPacket = (AVPacket *)av_malloc(sizeof(AVPacket));//动态分配内存
    
    // 7.2 创建音频采样数据帧
    AVFrame *avFrame = av_frame_alloc();
    
    //7.3 类型转换
    //音频采样上下文->开辟了一块内存空间->pcm 格式
    //设置参数：要保证视频能够正常播放，必须满足采样率44100HZ, 声道为双声道，编码为16位 PCM
    //参数一：s -> 音频采样数据上下文
    //上下文：保存音频信息
    SwrContext *swr_context = swr_alloc();
    //参数二：out_ch_layout -> 输出声道布局类型（立体声，环绕声、机器人等等。。。）
    int out_ch_layout = AV_CH_LAYOUT_STEREO;
    //int out_ch_layout = av_get_default_channel_layout(avcodec_context->channels);
    //参数三：out_sample_fmt -> 输出采样精度(编码)，例如：采样精度8位=每个像素点1字节，采样精度16位=2字节
    // 错误的写法
    //AVSampleFormat out_sample_fmt = avcodec_context->sample_fmt;
    // 正确写法：保证输出的编码是16位
    enum AVSampleFormat out_sample_fmt = AV_SAMPLE_FMT_S16;
    
    //参数四：out_sample_rate -> 输出采样率（一般是44100HZ）
    int out_sample_rate = avcodec_context->sample_rate;
    //参数五： in_ch_layout -> 输入声道布局类型
    int64_t in_ch_layout = av_get_default_channel_layout(avcodec_context->channels);
    //参数六： in_sample_fmt -> 输入采样精度
    enum AVSampleFormat in_sample_fmt = avcodec_context->sample_fmt;
    //参数七： in_sample_rate -> 输入采样率
    int in_sample_rate = avcodec_context->sample_rate;
    //参数八： log_offset ->  Log 日志
    int log_offset = 0;
    //参数九： log_ctx ->  Log 上下文
    
    swr_alloc_set_opts(swr_context,
                       out_ch_layout,
                       out_sample_fmt,
                       out_sample_rate,
                       in_ch_layout,
                       in_sample_fmt,
                       in_sample_rate,
                       log_offset,
                       NULL);
    // 初始化音频采样数据上下文
    swr_init(swr_context);
    
    //输出音频采样数据
    //缓冲区的大小 = 采样率(44100HZ) * 采样精度（16位 = 2字节）
    int MAX_AUDIO_SIZE = 44100 * 2;
    uint8_t *out_buffer = (uint8_t *)av_malloc(MAX_AUDIO_SIZE);
    
    //输出的声道数量
    int out_nb_channels = av_get_channel_layout_nb_channels(out_ch_layout);
    
    
    int audio_decode_result = 0;
    
    //7.5 打开文件
    const  char *coutfilePath = [targetFilePath UTF8String];
    FILE *out_file_pcm = fopen(coutfilePath, "wb");
    if (out_file_pcm == NULL) {
        NSLog(@"打开音频输出文件失败");
        return;
    }
    
    
    // 统计帧数
    int current_index = 0;
    
    while (av_read_frame(avformat_context, avPacket) >= 0) {
        //>=: 读取到了
        // <0:读取错误或者读取完毕
        // 6.2 判定是否是我们的音频流
        if (avPacket -> stream_index == av_stream_index) {
            //第七步：音频解码
            //7.1  发送一帧音频压缩数据包 得到 音频压缩数据帧
            avcodec_send_packet(avcodec_context, avPacket);
            //7.2  解码一帧音频压缩数据包，得到一帧音频采样数据帧
            audio_decode_result = avcodec_receive_frame(avcodec_context, avFrame);
            if (audio_decode_result == 0) {
                //解码成功
                NSLog(@"音频解码成功");
                
                //7.3 类型转换(音频采样数据格式有很多种)
                //将解码出来的的音频采样数据格式统一转为 pcm 格式
                //参数一：音频采样数据上下文
                //参数二：输出音频采样数据
                //参数三：输出音频采样数据的大小
                //参数四：输入音频采样数据
                //参数五：输入音频采样数据的大小
                swr_convert(swr_context,
                            &out_buffer,
                            MAX_AUDIO_SIZE,
                            (const uint8_t **)avFrame->data,
                            avFrame->nb_samples);
                
                //7.4 获取缓冲区实际存储大小
                //参数一：行大小，可以为 NULL
                //参数二：输出声道的数量
                //参数三：输入的大小
                int nb_samples = avFrame->nb_samples;
                //参数四：输出音频采样数据格式
                //参数五：字节对齐方式
                int out_buffer_size = av_samples_get_buffer_size(NULL,
                                                                 out_nb_channels,
                                                                 nb_samples,
                                                                 out_sample_fmt,
                                                                 1);
                
                
                
                
                //7.5 写入文件
                fwrite(out_buffer, 1, out_buffer_size, out_file_pcm);
                
                // 统计帧数
                current_index++;
                NSLog(@"当前解码第%d帧",current_index);//598帧
            }
        }
        
        
    }
    
    
    //第八步：释放内存资源，关闭音频
    fclose(out_file_pcm);
    av_packet_free(&avPacket);
    swr_free(&swr_context);
    av_free(out_buffer);
    av_frame_free(&avFrame);
    avcodec_close(avcodec_context);
    avformat_close_input(&avformat_context);
}

@end
