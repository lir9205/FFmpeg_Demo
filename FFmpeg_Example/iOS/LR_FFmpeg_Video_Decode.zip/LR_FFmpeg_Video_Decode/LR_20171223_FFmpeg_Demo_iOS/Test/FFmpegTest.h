//
//  FFmpegTest.h
//  LR_20171223_FFmpeg_Demo_iOS
//
//  Created by admin on 2017/12/23.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import <Foundation/Foundation.h>
// 音视频编解码
#import <libavcodec/avcodec.h>
// 音视频封装格式库
#import <libavformat/avformat.h>
// 音频采样数据格式库
#import <libswresample/swresample.h>
// 视频像素数据格式库
#import <libswscale/swscale.h>
// 工具库
#import <libavutil/imgutils.h>

@interface FFmpegTest : NSObject

/**
 视频解码
 
 @param sourceFilePath 输入文件->mp4、mov等等->封装格式
 @param targetFilePath 输出文件->YUV文件->视频像素数据格式
 */
+ (void)ffmpegDecodeVideoWithSourceFilePath:(NSString *)sourceFilePath targetFilePath:(NSString *)targetFilePath;

/**
 音频解码
 
 @param sourceFilePath 输入文件->mp4、mov等等->封装格式
 @param targetFilePath 输出文件->PCM文件->音频采样数据格式
 */
+ (void)ffmpegDecodeAudioWithSourceFilePath:(NSString *)sourceFilePath targetFilePath:(NSString *)targetFilePath;

@end
