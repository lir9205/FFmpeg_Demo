//
//  AppDelegate.h
//  LR_20171223_FFmpeg_Demo_iOS
//
//  Created by admin on 2017/12/23.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

