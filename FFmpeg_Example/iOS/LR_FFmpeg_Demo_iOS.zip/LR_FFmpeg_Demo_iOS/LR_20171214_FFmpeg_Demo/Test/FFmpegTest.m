//
//  FFmpegTest.m
//  LR_20171214_FFmpeg_Demo
//
//  Created by admin on 2017/12/14.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import "FFmpegTest.h"


@implementation FFmpegTest

// 测试 FFmpeg 配置
+ (void)ffmpegTestConfig {
    const char *configuration = avcodec_configuration();
    NSLog(@"配置信息：\n %s", configuration);
}
// 打开视频文件
+ (void)ffmpegVideoOpenfile:(NSString *)filePath {
    // 第一步：注册组件
    av_register_all();
    
    // 第二步：打开封装格式文件
    // 参数一 AVFormatContext **ps 封装格式上下文
    AVFormatContext *avformat_context = avformat_alloc_context();
    // 参数二 const char *url 打开视频地址path
    const char *url = [filePath UTF8String];
    // 参数三 AVInputFormat *fmt 指定输入封装格式 -> 默认格式
    // 参数四 AVDictionary **options 指定默认配置信息 -> 默认配置
    int avformat_open_input_result = avformat_open_input(&avformat_context, url, NULL, NULL);
    if (avformat_open_input_result != 0) {
        //打开失败
//        获取错误信息
//        char *errorInfo = NULL;
//        av_strerror(avformat_open_input_result, errorInfo, 1024);

        NSLog(@"打开文件失败");
        return;
    }
    NSLog(@"打开文件成功");
}

//视频解码
+ (void)ffmpegDecodeVideoWithSourceFilePath:(NSString *)sourceFilePath targetFilePath:(NSString *)targetFilePath {
    // 第一步：注册组件
    av_register_all();
    //    第二步：打开封装格式 -> 打开文件
    // 参数一 AVFormatContext **ps 封装格式上下文
    // 作用：保存整个视频信息（解码器，编码器等等...）
    // 信息：码率，帧率等...
    AVFormatContext *avformat_context = avformat_alloc_context();
    // 参数二 const char *url 打开视频路径
    // 将 ObjctiveC 的字符串转成 C语言的字符串
    const char *cfilePath = [sourceFilePath UTF8String];
    // 参数三 AVInputFormat *fmt 指定输入封装格式 -> 默认格式
    // 参数四 AVDictionary **options 指定默认配置信息 -> 默认配置
    int avformat_open_input_result =  avformat_open_input(&avformat_context, cfilePath, NULL, NULL);
    
    if (avformat_open_input_result != 0) {
//        __android_log_print(ANDROID_LOG_INFO, "main", "打开文件失败");
        NSLog(@"打开文件失败");
        return;
    }
    
    // 第三步： 查找视频流 -> 拿到视频信息
    // 参数一 AVFormatContext *ps 封装格式上下文
    // 参数二 AVDictionary **options 指定默认配置信息 -> 默认配置
    int avformat_find_stream_info_result = avformat_find_stream_info(avformat_context, NULL);
    if (avformat_find_stream_info_result < 0) {
//        __android_log_print(ANDROID_LOG_INFO, "main", "查找视频流失败");
        NSLog(@"查找视频流失败");
        return;
    }
    
    // 第四步：查找视频解码器
    // 1. 查找视频流索引位置
    int av_stream_index = -1;
    for (int i = 0; i < avformat_context -> nb_streams; ++i) {
        // 判断流类型：视频流、音频流、字母流。。。
        // codec 视频流的解码器；codec_type：解码器类型
        if (avformat_context->streams[i]->codec->codec_type == AVMEDIA_TYPE_VIDEO) {
            av_stream_index = i;
            break;
        }
        
        //        if (avformat_context->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO) {
        //            av_stream_index = i;
        //            break;
        //        }
    }
    
    //2. 根据视频流索引，获取解码器上下文
    AVCodecContext *avCodecContext = avformat_context->streams[av_stream_index]->codec;
    //    AVCodecParameters *avCodecParameters = avformat_context->streams[av_stream_index]->codecpar;
    
    //3. 根据解码器上下文，获得解码器ID，然后查找解码器
    AVCodec *avcodec = avcodec_find_decoder(avCodecContext->codec_id);
    
    //第五步：打开解码器
    int avcodec_open2_result = avcodec_open2(avCodecContext, avcodec, NULL);
    if (avcodec_open2_result != 0) {
//        __android_log_print(ANDROID_LOG_INFO, "main", "打开解码器失败");
        NSLog(@"打开解码器失败");
        return;
    }
    
    // 测试一下
    // 打印信息
//    __android_log_print(ANDROID_LOG_INFO, "main", "解码器名称：%s", avcodec->name);
    NSLog(@"解码器名称：%s", avcodec->name);
    
    //第六步：读取视频压缩数据->循环读取
    //每读取一帧数据，立马解码一帧数据
    // 1、分析av_read_frame()参数
    // 参数一：封装格式上下文
    // 参数二：一帧压缩数据 = 一帧图片
    // 结构体大小计算：字节对齐原则
    AVPacket *packet = (AVPacket *)av_malloc(sizeof(AVPacket));//动态分配内存
    
    
    //3.2 解码一帧视频压缩数据->进行解码（作用：用于解码操作）
    // 开辟一块内存空间
    AVFrame *avframe_in = av_frame_alloc();
    int decode_result = 0;
    
    //4、注意：这里不能够保证解码出来的一帧视频像素格式是 yuv 格式
    //参数一：源文件 -> 原始视频像素数据格式宽
    //参数二：源文件 -> 原始视频像素数据格式高
    //参数三：源文件 -> 原始视频像素数据格式类型
    //参数四：目标文件 -> 目标视频像素数据格式宽
    //参数五：目标文件 -> 目标视频像素数据格式高
    //参数六：目标文件 -> 目标视频像素数据格式类型
    struct SwsContext *swsContext = sws_getContext(avCodecContext->width,
                                            avCodecContext->height,
                                            avCodecContext->pix_fmt,
                                            avCodecContext->width,
                                            avCodecContext->height,
                                            AV_PIX_FMT_YUV420P,
                                            SWS_BICUBIC, NULL, NULL, NULL);
    
    
    //创建一个 yuv420p 视频像素数据格式缓冲区（一帧数据）
    AVFrame *avframe_yuv420p = av_frame_alloc();
    //给缓冲区设置类型->yuv420p 类型
    //得到 yuv420p缓冲区大小
    //参数一：视频像素数据格式类型 -> yuv420p格式
    //参数二：一帧视频像素数据宽 = 视频宽
    //参数三：一帧视频像素数据高 = 视频高
    //参数四：字节对齐方式->默认是1
    int buffer_size = av_image_get_buffer_size(AV_PIX_FMT_YUV420P,
                                               avCodecContext->width,
                                               avCodecContext->height,
                                               1);
    //开辟一块内存空间
    uint8_t *out_buffer = (uint8_t *)av_malloc(buffer_size);
    
    //向 avframe_yuv420p 填充数据
    //参数一：目标->填充数据（avframe_yuv420p）
    //参数二：目标->每一行大小
    //参数三：原始数据
    //参数四：目标->格式类型
    //参数五：宽
    //参数六：高
    //参数七：字节对齐方式->默认是1
    av_image_fill_arrays(avframe_yuv420p->data,
                         avframe_yuv420p->linesize,
                         out_buffer,
                         AV_PIX_FMT_YUV420P,
                         avCodecContext->width,
                         avCodecContext->height,
                         1);
    
    int y_size, u_size, v_size;
    
    //5.2 将 yuv420p 数据写入.yuv 文件
    //打开写入文件
    const char *outfile = [targetFilePath UTF8String];
    FILE *file_yuv420p = fopen(outfile, "wb+");
    if (file_yuv420p == NULL) {
//        __android_log_print(ANDROID_LOG_INFO, "main", "输出文件打开失败");
        NSLog(@"输出文件打开失败");
        return;
    }
    
    // 统计帧数
    int current_index = 0;
    
    
    //第六步：读取视频压缩数据->循环读取
    //每读取一帧数据，立马解码一帧数据
    // 1、分析av_read_frame()参数
    // 参数一：封装格式上下文
    // 参数二：一帧压缩数据 = 一帧图片
    // 结构体大小计算：字节对齐原则
    while (av_read_frame(avformat_context, packet) >= 0) {
        // >= 0: 读取到了
        // < 0:读取错误或者读取完毕
        // 2、判定是否是我们的视频流
        if (packet -> stream_index == av_stream_index) {
            //第七步：视频解码->播放视频->得到视频像素数据
            //3、解码一帧压缩数据->得到视频像素数据->yuv格式
            //采用新的 API
            //3.1 发送一帧视频压缩数据
            decode_result = avcodec_receive_frame(avCodecContext, avframe_in);
            //3.2 解码一帧视频压缩数据->进行解码（作用：用于解码操作）
            if (decode_result != 0) {
                //解码成功
//                __android_log_print(ANDROID_LOG_INFO, "main", "解码成功");
                NSLog(@"解码成功");
                
                //4、注意：这里不能够保证解码出来的一帧视频像素格式是 yuv 格式
                //视频像素数据格式有很多类型：yuv420p、yuv422p、yuv444p 等等...  yuv指的是色度空间，420指的是色度抽样
                //保证我的解码后的视频像素数据格式统一为 yuv420p -> 通用的格式
                //进行类型转换：将解码出来的视频像素点数据格式->统一转类型为yuv420p
                //sws_scale作用：进行类型转换的
                //参数一：视频像素数据格式上下文
                //参数二：原来的视频像素格式 -> 输入数据
                //参数三：原来的视频像素格式 -> 输入画面每一行大小
                //参数四：原来的视频像素格式 -> 输入画面每一行开始位置（填写：0 -> 表示从原点开始读取）
                //参数五：原来的视频像素格式 -> 输入数据行数
                //参数六：转换类型后视频像素数据格式->输出数据
                //参数七：转换类型后视频像素数据格式->输出画面每一行大小
                sws_scale(swsContext,
                          (const uint8_t *const *)avframe_in->data,
                          avframe_in->linesize,
                          0,
                          avCodecContext->height,
                          avframe_yuv420p->data,
                          avframe_yuv420p->linesize);
                //方式一：直接显示在屏幕上面去
                //方式二：写入 yuv 文件格式
                //5、将 yuv420p数据写入.yuv 文件中
                //5.1 计算 YUV 大小
                //分析一下原理？
                //Y: 亮度，UV: 色度
                //有规律
                //YUV420P 格式规范一：Y结构表示一个像素（一个像素对应一个 Y）
                //YUV420P 格式规范二：四个像素点对应一个（ U 和 V：4Y = U = V）
                y_size = avCodecContext->width * avCodecContext->height;
                u_size = y_size / 4;
                v_size = y_size / 4;
                
                //5.2 写入.yuv 文件
                //  yuv格式从左到右，自上而下的顺序排版
                //首先 y 数据
                fwrite(avframe_yuv420p->data[0], 1, y_size, file_yuv420p);
                //其次 u 数据
                fwrite(avframe_yuv420p->data[1], 1, u_size, file_yuv420p);
                //再其次 v 数据
                fwrite(avframe_yuv420p->data[2], 1, v_size, file_yuv420p);
                
                current_index++;
//                __android_log_print(ANDROID_LOG_INFO,"main","当前解码第%d帧",current_index);//598帧
                NSLog(@"当前解码第%d帧",current_index);
            }
        }
        
        
    }
    
    
    //第八步：释放内存资源，关闭解码器->解码完成
    // 注意释放顺序，不要搞反了
    av_packet_free(&packet);
    fclose(file_yuv420p);
    av_frame_free(&avframe_in);
    av_frame_free(&avframe_yuv420p);
    free(out_buffer);
    avcodec_close(avCodecContext);
    avformat_free_context(avformat_context);

}
@end
