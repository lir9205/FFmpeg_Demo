//
//  FFmpegTest.h
//  LR_20171214_FFmpeg_Demo
//
//  Created by admin on 2017/12/14.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import <Foundation/Foundation.h>
//引入头文件
//核心库 -> 音视频编解码库
#import <libavcodec/avcodec.h>
//导入封装格式库
#import <libavformat/avformat.h>
//视频像素格式库
#import <libswscale/swscale.h>
//工具库
#import <libavutil/imgutils.h>

@interface FFmpegTest : NSObject

/**
 测试 FFmpeg 配置
 */
+ (void)ffmpegTestConfig;

/**
 打开视频文件

 @param filePath 视频文件路径
 */
+ (void)ffmpegVideoOpenfile:(NSString *)filePath;



/**
 视频解码

 @param sourceFilePath 原视频文件路径
 @param targetFilePath 目标文件路径
 */
+ (void)ffmpegDecodeVideoWithSourceFilePath:(NSString *)sourceFilePath targetFilePath:(NSString *)targetFilePath;

@end
