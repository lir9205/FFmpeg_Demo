//
//  main.m
//  LR_20171214_FFmpeg_Demo
//
//  Created by admin on 2017/12/14.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
