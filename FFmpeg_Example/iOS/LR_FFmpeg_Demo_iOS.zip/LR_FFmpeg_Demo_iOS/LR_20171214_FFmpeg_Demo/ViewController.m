//
//  ViewController.m
//  LR_20171214_FFmpeg_Demo
//
//  Created by admin on 2017/12/14.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import "ViewController.h"
#import "FFmpegTest.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    // 测试一
    [FFmpegTest ffmpegTestConfig];
    
    // 测试二
    NSString *path = [[NSBundle mainBundle] pathForResource:@"Test.mov" ofType:nil];
    [FFmpegTest ffmpegVideoOpenfile:path];
    
    // 测试三
    NSString *sourcePath = [[NSBundle mainBundle] pathForResource:@"Test.mov" ofType:nil];
    
    NSString *docDic = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    NSString *targetPath = [docDic stringByAppendingPathComponent:@"/Test.yuv"];
    NSLog(@"sourcePath: %@,targetPath: %@", sourcePath, targetPath);
    [FFmpegTest ffmpegDecodeVideoWithSourceFilePath:sourcePath targetFilePath:targetPath];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
