//
//  FFmpegTest.m
//  LR_20171223_FFmpeg_Demo_iOS
//
//  Created by admin on 2017/12/23.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import "FFmpegTest.h"

int flush_encoder(AVFormatContext *fmt_ctx, unsigned int stream_index) {
    int ret;
    int got_frame;
    AVPacket enc_pkt;
    if (!(fmt_ctx->streams[stream_index]->codec->codec->capabilities &
          CODEC_CAP_DELAY))
        return 0;
    while (1) {
        enc_pkt.data = NULL;
        enc_pkt.size = 0;
        av_init_packet(&enc_pkt);
        ret = avcodec_encode_video2(fmt_ctx->streams[stream_index]->codec, &enc_pkt,
                                    NULL, &got_frame);
        av_frame_free(NULL);
        if (ret < 0)
            break;
        if (!got_frame) {
            ret = 0;
            break;
        }
        NSLog(@"Flush Encoder: Succeed to encode 1 frame!\tsize:%5d\n", enc_pkt.size);
        /* mux encoded frame */
        ret = av_write_frame(fmt_ctx, &enc_pkt);
        if (ret < 0)
            break;
    }
    return ret;
}

@implementation FFmpegTest


//  音频编码  将 yuv420P(4个Y 共用一个 UV) 编码为 h264
+ (void)ffmpegAudioEncode:(NSString *)inFilePath outFilePath:(NSString *)outFilePath {
    // 第一步：注册组件->音频编码器、音频解码器等等…
    av_register_all();
    
    // 第二步：初始化封装格式上下文 -> 音频编码 -> 处理为音频压缩数据格式
    AVFormatContext *avformat_context = avformat_alloc_context();
    // 注意事项：通过 FFmpeg 程序推测输出文件（音频压缩数据格式）的类型 -> aac 格式
    const char *coutFilePath = [outFilePath UTF8String];
    // 得到音频压缩数据格式类型（ aac，mp3...）
    AVOutputFormat *avoutput_format = av_guess_format(NULL, coutFilePath, NULL);
    // 指定类型
    avformat_context->oformat = avoutput_format;
    
    // 第三步：打开输出文件
    // 参数一：输出流
    // 参数二：输出文件
    // 参数三：权限 -> 输出到文件中
    int avio_open_result = avio_open(&avformat_context->pb, coutFilePath, AVIO_FLAG_WRITE);
    if (avio_open_result < 0) {
        NSLog(@"输出文件打开失败");
        return;
    }
    NSLog(@"输出文件打开成功");
    
    // 第四步：创建输出码流->创建了一块内存空间->并不知道他是什么类型流->今后设置为音频流
    AVStream *av_audio_stream = avformat_new_stream(avformat_context, NULL);
    
    // 第五步：查找音频编码器
    //1、获取编码器上下文
    AVCodecContext *avcodec_context = av_audio_stream->codec;
    
    //2、设置编解码器上下文参数
    //目标：设置为是一个音频编码器上下文 -> 指定的是音频编码器
    //上下文种类：视频解码器、视频编码器、音频解码器、音频编码器
    //2.1 设置音频编码器 ID
    avcodec_context->codec_id = avoutput_format->audio_codec;
    //2.2 设置编码器类型 -> 音频编码器
    avcodec_context->codec_type = AVMEDIA_TYPE_AUDIO;
    //2.3 设置读取音频采样数据格式-> 编码的是音频采样数据格式 -> 音频采样数据格式 -> pcm格式
    //注意：这个类型是根据你解码的时候指定的解码的音频采样数据格式类型
    avcodec_context->sample_fmt = AV_SAMPLE_FMT_S16;
    //注意报错："Specified sample format s16 is invalid or not supported",
    // 说明编码器不支持这种音频采样数据格式->AV_SAMPLE_FMT_S16
    // 解决办法：让我们的编码器支持这种音频采样数据格式->AV_SAMPLE_FMT_S16
    // 查看编码器（`./configure --list-encoders`） -> 换一个编码器
    // 老的 ffmpeg 框架里面是 faac 格式
    // 新的 ffmpeg 框架里面是  libfdk_aac 格式
    // faac 和 libfdk_aac 的区别
    // libfdk_aac编码出来的音频质量高，占用内存少，相当于 faac 的升级版，算法不一样，更优化
    
    
    
    //2.4 设置采样率
    avcodec_context->sample_rate = 44100;
    //2.5 设置立体声
    avcodec_context->channel_layout = AV_CH_LAYOUT_STEREO;
    //2.6 设置声道数量
    int channels = av_get_channel_layout_nb_channels(avcodec_context->channel_layout);
    avcodec_context->channels = channels;
    //2.7 设置码率  ????
    //基本算法是：[码率](kb/s) = [视频大小 - 音频大小]（bit 位）/[时间]（秒）
    avcodec_context->bit_rate = 128000;
    
    //3、查找音频编码器 -> aac
    //    AVCodec *avcodec = avcodec_find_encoder(avcodec_context->codec_id);
    AVCodec *avcodec = avcodec_find_encoder_by_name("libfdk_aac");
    if (avcodec == NULL) {
        NSLog(@"找不到音频编码器");
        return;
    }
    NSLog(@"找到了音频编码器，名称为：%s",avcodec->name);
    
    //第六步：打开音频编码器
    int avcodec_open2_result =  avcodec_open2(avcodec_context, avcodec, NULL);
    
    if (avcodec_open2_result < 0) {
        NSLog(@"打开音频编码器失败");
        return;
    }
    
    NSLog(@"打开音频编码器成功");
    
    
    //第七步：写入文件头信息（有些文件没有头信息）->一般情况下都会有
    avformat_write_header(avformat_context, NULL);
    
    //第八步：循环编码 yuv 文件（视频像素数据 yuv 格式）-> 编码成音频压缩数据（h264格式）
    //8.1 定义一个缓冲区，作用：缓存一帧视频像素数据
    //8.1.1 获取缓冲区大小
    int buffer_size = av_samples_get_buffer_size(NULL,
                                                 avcodec_context->channels,
                                                 avcodec_context->frame_size,
                                                 avcodec_context->sample_fmt,
                                                 1);
    //8.1.2 创建一个缓冲区 -> 存储音频采样数据 -> 专门用来缓存一帧数据
    uint8_t *out_buffer = (uint8_t *)av_malloc(buffer_size);
    
    //8.1.3 打开输入文件
    const char *cinFilePath = [inFilePath UTF8String];
    FILE *in_file = fopen(cinFilePath, "rb");
    if (in_file == NULL) {
        NSLog(@"输入文件打开失败");
        return;
    }
    NSLog(@"输入文件打开成功");
    
    
    //8.2.1 初始化音频采样数据帧缓冲区
    AVFrame *av_frame = av_frame_alloc();//这里只是开辟了内存空间没有数据
    av_frame->nb_samples = avcodec_context->frame_size;
    av_frame->format = avcodec_context->sample_fmt;
    
    //8.2.2 设置这块缓冲区和 AVFrame 的类型保持一致 -> 填充数据
    avcodec_fill_audio_frame(av_frame,
                             avcodec_context->channels,
                             avcodec_context->sample_fmt,
                             (const uint8_t *)out_buffer,
                             buffer_size,
                             1);
    
    int i = 0;
    
    //9.2 接收一帧视频像素数据 -> 编码为视频压缩数据格式
    AVPacket *av_packet = (AVPacket *)av_malloc(buffer_size);
    // 编码结果
    int result = 0;
    
    //统计编码的帧
    int current_frame_index = 1;
    
    while (true) {
        //8.1 从yuv文件里面读取一帧，
        // 读取一帧大小：y_size * 3 / 2  = y_size + (y_size/4) + (y_size/4)
        if (fread(out_buffer, 1, buffer_size, in_file) <= 0) {
            NSLog(@"读取完毕...");
            break;
        } else if (feof(in_file)) {
            break;
        }
        
        //8.2 将缓冲区数据转成 AVFrame 类型
        // 给 AVFrame 填充数据
        //8.2.3 void * restrict 转成 AVFrame（FFmpeg 数据类型）
        av_frame->data[0] = out_buffer;
        // 帧数
        av_frame->pts = i;
        // 注意时间戳
        i++;
        //总结：这样一来我们的 AVFrame 就有数据了
        
        //第九步：视频编码处理
        //9.1 发送一帧视频像素数据
        avcodec_send_frame(avcodec_context, av_frame);
        //9.2 接收一帧视频像素数据 -> 编码为视频压缩数据格式
        result = avcodec_receive_packet(avcodec_context, av_packet);
        
        //9.3 判断是否编码成功
        if (result == 0) {
            //编码成功
            // 第十步：将视频压缩数据写入到输出文件中 -> outFilePath
            av_packet->stream_index = av_audio_stream->index;
            result = av_write_frame(avformat_context, av_packet);
            
            NSLog(@"当前是第%d 帧", current_frame_index);
            current_frame_index++;
            
            // 是否输出成功
            if (result < 0) {
                NSLog(@"输出一帧数据失败");
                return;
            }
        }
    }
    
    //第十一步：写入剩余帧数据 -> 可能没有
    result = flush_encoder(avformat_context, 0);
    if (result < 0) {
        NSLog(@"Flushing encoder failed");
        return;
    }
    //第十二步：写入文件尾部信息
    av_write_trailer(avformat_context);
    //第十三步：释放内存
    avcodec_close(avcodec_context);
    av_free(av_frame);
    av_free(out_buffer);
    av_packet_free(&av_packet);
    avio_close(avformat_context->pb);
    avformat_free_context(avformat_context);
    fclose(in_file);
    
}
@end
