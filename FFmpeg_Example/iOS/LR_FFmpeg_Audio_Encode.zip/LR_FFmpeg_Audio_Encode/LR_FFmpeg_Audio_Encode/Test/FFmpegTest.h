//
//  FFmpegTest.h
//  LR_20171223_FFmpeg_Demo_iOS
//
//  Created by admin on 2017/12/23.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import <Foundation/Foundation.h>
// 音视频编解码
#import <libavcodec/avcodec.h>
// 音视频封装格式库
#import <libavformat/avformat.h>
// 工具库
#import <libavutil/imgutils.h>
// 音频采样数据格式库
#import <libswresample/swresample.h>

@interface FFmpegTest : NSObject

/**
 FFmpeg音频编码
 
 @param inFilePath 输入文件-> PCM文件-> 音频采样数据格式
 @param outFilePath 输出文件-> AAC文件-> 音频压缩数据格式
 */
+ (void)ffmpegAudioEncode:(NSString *)inFilePath outFilePath:(NSString *)outFilePath;

@end
