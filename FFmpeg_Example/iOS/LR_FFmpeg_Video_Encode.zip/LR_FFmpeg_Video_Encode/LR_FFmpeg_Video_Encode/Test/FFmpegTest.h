//
//  FFmpegTest.h
//  Dream_20171113_FFmpeg_Test_Hello
//
//  Created by Dream on 2017/11/13.
//  Copyright © 2017年 Tz. All rights reserved.
//

#import <Foundation/Foundation.h>
//核心库
#include "libavcodec/avcodec.h"
//封装格式处理库
#include "libavformat/avformat.h"
//工具库
#include "libavutil/imgutils.h"

@interface FFmpegTest : NSObject


/**
 FFmpeg视频编码

 @param inFilePath 输入文件->YUV文件->视频像素数据格式
 @param outFilePath 输出文件->H264文件->视频压缩数据格式
 */
+(void)ffmpegVideoEncode:(NSString*)inFilePath outFilePath:(NSString*)outFilePath;


/**
 FFmpeg音频编码

 @param inFilePath 输入文件-> PCM文件-> 音频采样数据格式
 @param outFilePath 输出文件-> AAC文件-> 音频压缩数据格式
 */
+(void)ffmpegAudioEncode:(NSString*)inFilePath outFilePath:(NSString*)outFilePath;
    
@end
