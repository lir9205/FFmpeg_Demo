//
//  FFmpegTest.m
//  Dream_20171113_FFmpeg_Test_Hello
//
//  Created by Dream on 2017/11/13.
//  Copyright © 2017年 Tz. All rights reserved.
//

#import "FFmpegTest.h"

int flush_encoder(AVFormatContext *fmt_ctx, unsigned int stream_index) {
    int ret;
    int got_frame;
    AVPacket enc_pkt;
    if (!(fmt_ctx->streams[stream_index]->codec->codec->capabilities &
          CODEC_CAP_DELAY))
        return 0;
    while (1) {
        enc_pkt.data = NULL;
        enc_pkt.size = 0;
        av_init_packet(&enc_pkt);
        ret = avcodec_encode_video2(fmt_ctx->streams[stream_index]->codec, &enc_pkt,
                                    NULL, &got_frame);
        av_frame_free(NULL);
        if (ret < 0)
            break;
        if (!got_frame) {
            ret = 0;
            break;
        }
        NSLog(@"Flush Encoder: Succeed to encode 1 frame!\tsize:%5d\n", enc_pkt.size);
        /* mux encoded frame */
        ret = av_write_frame(fmt_ctx, &enc_pkt);
        if (ret < 0)
            break;
    }
    return ret;
}

@implementation FFmpegTest


// 视频编码  将 yuv420P(4个Y 共用一个 UV) 编码为 h264
+ (void)ffmpegVideoEncode:(NSString *)inFilePath outFilePath:(NSString *)outFilePath {
    // 第一步：注册组件->编码器、解码器等等…
    av_register_all();
    
    // 第二步：初始化封装格式上下文 -> 视频编码 -> 处理为视频压缩数据格式
    AVFormatContext *avformat_context = avformat_alloc_context();
    // 注意事项：通过 FFmpeg 程序推测输出文件（视频压缩数据格式）的类型
    const char *coutFilePath = [outFilePath UTF8String];
    // 得到视频压缩数据格式类型（h264，h265，mpeg2...）
    AVOutputFormat *avoutput_format = av_guess_format(NULL, coutFilePath, NULL);
    // 指定类型
    avformat_context->oformat = avoutput_format;
    
    // 第三步：打开输出文件
    // 参数一：输出流
    // 参数二：输出文件
    // 参数三：权限 -> 输出到文件中
    int avio_open_result = avio_open(&avformat_context->pb, coutFilePath, AVIO_FLAG_WRITE);
    if (avio_open_result < 0) {
        NSLog(@"输出文件打开失败");
        return;
    }
    NSLog(@"输出文件打开成功");
    
    // 第四步：创建输出码流->视频流->今后设置为视频流
    AVStream *av_video_stream = avformat_new_stream(avformat_context, NULL);
    
    // 第五步：查找视频编码器
    //1、获取编码器上下文
    AVCodecContext *avcodec_context = av_video_stream->codec;
    
    //2、设置编解码器上下文参数
    //目标：设置为是一个视频编码器上下文 -> 指定的是视频编码器
    //上下文种类：视频解码器、视频编码器、音频解码器、音频编码器
    //2.1 设置视频编码器 ID
    avcodec_context->codec_id = avoutput_format->video_codec;
    //2.2 设置编码器类型 -> 视频编码器
    avcodec_context->codec_type = AVMEDIA_TYPE_VIDEO;
    //2.3 设置读取像素数据格式-> 编码的是像素数据格式 -> 视频像素数据格式 -> YUV420P(YUV422P、YUV444P...)
    //注意：这个类型是根据你解码的时候指定的解码的视频像素数据格式类型
    avcodec_context->pix_fmt = AV_PIX_FMT_YUV420P;
    //2.4 设置视频的尺寸（宽高）
    avcodec_context->width = 640;
    avcodec_context->height = 352;
    //2.5 设置帧率 -> (25fps) 每秒25帧
    avcodec_context->time_base.num = 1;//一秒
    avcodec_context->time_base.den = 25;//帧数
    //2.6 设置码率
    //2.6.1 什么是码率（比特率）？
    // 比特率是指每秒传送的比特(bit)数。单位为 bps(Bit Per Second)，比特率越高，传送数据速度越快。
    //2.6.2 什么是视频码率？
    // 含义：视频码率就是数据传输时单位时间传送的数据位数，一般我们用的单位是kbps即千位每秒。
    // 基本的算法是：【视频码率】(kbps)=【视频文件大小】(MB) /【时间】(秒)
    // 例如：Test.mov 时间：24秒  ，文件大小（视频 + 音频）= 1.73 MB
    // 视频大小 = 1.34MB(文件占比：77%) = 1.34 * 1024 * 1024 * 8 bit = 11240734.7 bit
    // 音频大小 = 376KB(文件占比：21%)
    // 计算出来的值->码率：468bps = (11240734.7 / 1000) / 24s -> K 表示1000，b 表示 bit 位；
    // 总结：码率越大，视频越大
    avcodec_context->bit_rate = 468000;
    
    //2.7 设置 GOP （会影响视频的质量问题 -> 画面组 -> 一组连续的画面）
    // MPEG画面类型（3钟）：I 帧、P 帧、B 帧
    // I帧：内部编码帧，是原始帧（原始视频数据）->
    //     完整画面，是关键帧（必须得有，如果没有 I 帧，那么无法进行编码、解码）
    //     视频序列的第一帧始终是 I 帧，因为它是关键帧。
    // P 帧：向前预测帧 -> 预测前面的一帧类型，处理数据（前面：I帧、帧）
    // B 帧：前后预测帧（双向预测帧）-> 前面一帧和后面一帧
    // B 帧压缩率高，但对解码性能的要求较高。
    // 总结：I 帧只需要考虑自己这一帧，P 帧考虑自己和前面一帧，B帧考虑自己和前后两帧。
    // 说白了P 帧和 B帧是对 I帧的压缩，I帧不能太少，否则会失真。
    
    //每250帧插入1个I帧，I帧越少，视频越小。取默认值。
    avcodec_context->gop_size = 250;
    
    //2.8 设置量化参数 -> 全是高级的数学方法
    //总结：量化系数越小，视频越是清晰。一般情况下都是默认值，最小量化系数默认值是10，最大量化系数默认值是51。
    avcodec_context->qmin = 10;
    avcodec_context->qmax = 51;
    
    //2.9 设置B帧的最大值 -> 设置不需要 B 帧
    avcodec_context->max_b_frames = 0;
    
    //3、查找编码器 -> h264
    // 找不到 h264编码器，主要原因是因为编译库没有依赖libx264库（默认情况下FFmpeg没有编译进来h264库）
    // 解决办法：
    // ①首先编译 libx264库的.a静态库 -> 脚本;
    // ②其次将 libx264库加入到 ffmpeg 库里面；
    // ③修改脚本文件重新编译 FFmpeg
    AVCodec *avcodec = avcodec_find_encoder(avcodec_context->codec_id);
    if (avcodec == NULL) {
        NSLog(@"找不到视频编码器");
        return;
    }
    NSLog(@"找到了视频编码器，名称为：%s",avcodec->name);
    
    //第六步：打开视频编码器
    
    // 缺少优化步骤
    // 解决编码的延时问题
    AVDictionary *params = 0;
    if (avcodec_context->codec_id == AV_CODEC_ID_H264) {
        //需要查看 x264源码 -> x264.c 文件
        //第一个值：预备参数
        //key: preset
        //value:slow -> 慢, superfast -> 超快
        av_dict_set(&params, "preset", "slow", 0);
        //第二个值：调优
        //key: tune -> 调优
        //value:zerolatency -> 零延迟
        av_dict_set(&params, "tune", "zerolatency", 0);
        
    }
    
    
    int avcodec_open2_result =  avcodec_open2(avcodec_context, avcodec, &params);
    
    if (avcodec_open2_result < 0) {
        NSLog(@"打开视频编码器失败");
        return;
    }
    
    NSLog(@"打开视频编码器成功");
    
    
    //第七步：写入文件头信息（有些文件没有头信息）->一般情况下都会有
    avformat_write_header(avformat_context, NULL);
    
    //第八步：循环编码 yuv 文件（视频像素数据 yuv 格式）-> 编码成视频压缩数据（h264格式）
    //8.1 定义一个缓冲区，作用：缓存一帧视频像素数据
    //8.1.1 获取缓冲区大小
    int buffer_size = av_image_get_buffer_size(avcodec_context->pix_fmt,
                                               avcodec_context->width,
                                               avcodec_context->height,
                                               1);
    //8.1.2 创建一个缓冲区
    int y_size = avcodec_context->width * avcodec_context->height;
    
    uint8_t *out_buffer = (uint8_t *)av_malloc(buffer_size);
    
    //8.1.3 打开输入文件
    const char *cinFilePath = [inFilePath UTF8String];
    FILE *in_file = fopen(cinFilePath, "rb");
    if (in_file == NULL) {
        NSLog(@"输入文件打开失败");
        return;
    }
    NSLog(@"输入文件打开成功");
    
    
    //8.2.1 av_frame_alloc 开辟一块内存空间没有数据
    AVFrame *av_frame = av_frame_alloc();//这里只是开辟了内存空间没有数据
    
    //8.2.2 设置这块缓冲区和 AVFrame 的类型保持一致 -> 填充数据
    av_image_fill_arrays(av_frame->data,
                         av_frame->linesize,
                         out_buffer,
                         avcodec_context->pix_fmt,
                         avcodec_context->width,
                         avcodec_context->height,
                         1);
    
//    int av_image_fill_arrays(uint8_t *dst_data[4], int dst_linesize[4],
//                             const uint8_t *src,
//                             enum AVPixelFormat pix_fmt, int width, int height, int align);
    
    int i = 0;
    
    //9.2 接收一帧视频像素数据 -> 编码为视频压缩数据格式
    AVPacket *av_packet = (AVPacket *)av_malloc(buffer_size);
    // 编码结果
    int result = 0;
    
    //统计编码的帧
    int current_frame_index = 1;
    
    while (true) {
        //8.1 从yuv文件里面读取一帧，
        // 读取一帧大小：y_size * 3 / 2  = y_size + (y_size/4) + (y_size/4)
        if (fread(out_buffer, 1, y_size * 3 / 2, in_file) <= 0) {
            NSLog(@"读取完毕...");
            break;
        } else if (feof(in_file)) {
            break;
        }
        
        //8.2 将缓冲区数据转成 AVFrame 类型
        // 给 AVFrame 填充数据
        //8.2.3 void * restrict 转成 AVFrame（FFmpeg 数据类型）
        // Y值
        av_frame->data[0] = out_buffer;
        // U值
        av_frame->data[1] = out_buffer + y_size;//
        // V值
        av_frame->data[2] = out_buffer + y_size * 5 / 4; //y_size * 5 / 4 = y_size + (y_size/4) = Y值加上U值
        // 帧数
        av_frame->pts = i;
        //总结：这样一来我们的 AVFrame 就有数据了
        // 注意时间戳
        i++;
        
        //第九步：视频编码处理
        //9.1 发送一帧视频像素数据
        avcodec_send_frame(avcodec_context, av_frame);
        //9.2 接收一帧视频像素数据 -> 编码为视频压缩数据格式
        result = avcodec_receive_packet(avcodec_context, av_packet);
        
        //9.3 判断是否编码成功
        if (result == 0) {
            //编码成功
            // 第十步：将视频压缩数据写入到输出文件中 -> outFilePath
            av_packet->stream_index = av_video_stream->index;
            result = av_write_frame(avformat_context, av_packet);
            
            NSLog(@"当前是第%d 帧", current_frame_index);
            current_frame_index++;
            
            // 是否输出成功
            if (result < 0) {
                NSLog(@"输出一帧数据失败");
                return;
            }
        }
    }
        
    //第十一步：写入剩余帧数据 -> 可能没有
    flush_encoder(avformat_context, 0);
    //第十二步：写入文件尾部信息
    av_write_trailer(avformat_context);
    //第十三步：释放内存
    avcodec_close(avcodec_context);
    av_free(av_frame);
    av_free(out_buffer);
    av_packet_free(&av_packet);
    avio_close(avformat_context->pb);
    avformat_free_context(avformat_context);
    fclose(in_file);
    
}

    
@end
