//
//  main.m
//  LR_FFmpeg_Video_Encode
//
//  Created by admin on 2017/12/29.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
