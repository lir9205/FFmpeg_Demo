//
//  ViewController.m
//  LR_FFmpeg_Video_Encode
//
//  Created by admin on 2017/12/29.
//  Copyright © 2017年 lirui. All rights reserved.
//

#import "ViewController.h"
#import "FFmpegTest.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self videoEncode];
}

//视频编码
- (void)videoEncode {
    
    NSString* inPath = [[NSBundle mainBundle] pathForResource:@"Test" ofType:@"yuv"];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,
                                                         
                                                         NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    NSString *tmpPath = [path stringByAppendingPathComponent:@"temp"];
    [[NSFileManager defaultManager] createDirectoryAtPath:tmpPath withIntermediateDirectories:YES attributes:nil error:NULL];
    NSString* outFilePath = [tmpPath stringByAppendingPathComponent:[NSString stringWithFormat:@"Test.h264"]];
    
    [FFmpegTest ffmpegVideoEncode:inPath outFilePath:outFilePath];
    
    NSLog(@"inFilepath: %@, outFilePath: %@", inPath, outFilePath);
    
}

@end
