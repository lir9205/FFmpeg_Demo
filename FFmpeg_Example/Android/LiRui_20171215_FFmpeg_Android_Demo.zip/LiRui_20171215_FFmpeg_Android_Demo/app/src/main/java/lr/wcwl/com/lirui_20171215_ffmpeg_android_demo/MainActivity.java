package lr.wcwl.com.lirui_20171215_ffmpeg_android_demo;

import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
//    static {
//        System.loadLibrary("native-lib");
//    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //测试
        FFmpegTest.ffmpegTestConfig();

        // 2、 打开视频文件
//        获取 sdcard 路径，需在 AndroidMainifest.xml 中，开启 sdcard 读写权限才能打开视频
        String rootPath= Environment.getExternalStorageDirectory().getAbsolutePath();
        String inFilePath = rootPath.concat("/Test.mov");
        FFmpegTest.ffmpegVideoOpenfile(inFilePath);
    }


}
