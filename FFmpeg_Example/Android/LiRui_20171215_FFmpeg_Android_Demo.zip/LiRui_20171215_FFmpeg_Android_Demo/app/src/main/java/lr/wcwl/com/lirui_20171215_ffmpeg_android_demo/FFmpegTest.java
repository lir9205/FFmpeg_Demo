package lr.wcwl.com.lirui_20171215_ffmpeg_android_demo;

/**
 * Created by admin on 2017/12/15.
 */

public class FFmpegTest {

//    加载动态库
    static {
        System.loadLibrary("native-lib");
}

//    1、测试 FFmpeg 配置
//    static相当于类方法
//    native标记这个方法是一个特殊的方法，它不是普通的 Java 方法，而是用于与 NDK 交互的方法（C/C++交互方法）
//    用 native 进行修饰的方法没有实现，具体实现在 C/C++ 里面
//    如果没有再 C/C++ 里面配置这个方法，这里会报错
    public static native void ffmpegTestConfig();

//2、 // 打开视频文件
    public  static native void ffmpegVideoOpenfile(String filePath);
}
