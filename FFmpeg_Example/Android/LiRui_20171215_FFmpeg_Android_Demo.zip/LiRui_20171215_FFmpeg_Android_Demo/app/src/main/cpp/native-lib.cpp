#include <jni.h>
#include <string>
#import <android/log.h>

//jni 是 Java 和 C/C++ 之间的一个中间件，是 Java 调 C/C++ 的一个机制

extern "C" {

//注意写法

//底层开发一模一样，Android 配置麻烦一点

//引入头文件
//核心库 -> 音视频编解码库
#include <libavcodec/avcodec.h>
//导入封装格式库
#include <libavformat/avformat.h>

// 声明方法 lirui_20171215_ffmpeg_android_demo  lr.wcwl.com.lirui_20171215_ffmpeg_android_demo
JNIEXPORT void JNICALL Java_lr_wcwl_com_lirui_120171215_1ffmpeg_1android_1demo_FFmpegTest_ffmpegTestConfig(
        JNIEnv *env,
        jobject);

JNIEXPORT void JNICALL Java_lr_wcwl_com_lirui_120171215_1ffmpeg_1android_1demo_FFmpegTest_ffmpegVideoOpenfile(
        JNIEnv *env,
        jobject jobj, jstring jfilePath);
}

// 方法实现
JNIEXPORT void JNICALL Java_lr_wcwl_com_lirui_120171215_1ffmpeg_1android_1demo_FFmpegTest_ffmpegTestConfig(
        JNIEnv *env,
        jobject /* this */) {

    const char *configuration = avcodec_configuration();
    //ANDROID_LOG_INFO ：安卓下直接打印消息

    __android_log_print( ANDROID_LOG_INFO,"main", "配置信息：%s", configuration);
}

//音视频编解码技术核心功能是跨平台实现，不需要修改，修改的是和语言直接连接代码
JNIEXPORT void JNICALL Java_lr_wcwl_com_lirui_120171215_1ffmpeg_1android_1demo_FFmpegTest_ffmpegVideoOpenfile(
        JNIEnv *env,
        jobject jobj, jstring jfilePath) {
    // 第一步：注册组件
    av_register_all();

    // 第二步：打开封装格式文件
    // 参数一 AVFormatContext **ps 封装格式上下文
    AVFormatContext *avformat_context = avformat_alloc_context();
    // 参数二 const char *url 打开视频地址path
    // 将 Java 的字符串转成 C语言的字符串
    const char *cfilePath = env->GetStringUTFChars(jfilePath, NULL);
    // 参数三 AVInputFormat *fmt 指定输入封装格式 -> 默认格式
    // 参数四 AVDictionary **options 指定默认配置信息 -> 默认配置
    int avformat_open_input_result = avformat_open_input(&avformat_context, cfilePath, NULL, NULL);
    if (avformat_open_input_result != 0) {
        //打开失败
//        获取错误信息
//        char *errorInfo = NULL;
//        av_strerror(avformat_open_input_result, errorInfo, 1024);

        __android_log_print(ANDROID_LOG_INFO, "Main", "打开文件失败");
        return;
    }
    __android_log_print(ANDROID_LOG_INFO, "Main", "打开文件成功");
}