package lr.wcwl.com.lr_20171223_ffmpeg_audio_decode;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String rootPath = Environment.getExternalStorageDirectory().getAbsolutePath();
        String inFilePath = rootPath.concat("/Test.mov");
        String outFilePath = rootPath.concat("/Test.pcm");

        Log.i("main","目录：" + inFilePath);

        // 如果文件不存在就创建一个文件
        File file = new File(outFilePath);
        if (file.exists()) {
            Log.i("日志", "存在");
        } else {
            try {
                file.createNewFile();
            } catch ( IOException e) {
                e.printStackTrace();
            }
        }
        ffmpegAudioDecode(inFilePath, outFilePath);

    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */


    public native void ffmpegAudioDecode(String infilePath, String outFilePath);
}
